param ([string]$DeployPath, [string]$SiteUrl, [string]$UserName, [string]$Password)
# If your password have some $ on it, the deploys will fail !

Write-Host "DeployPath [$($DeployPath)]"
Write-Host "SiteUrl [$($SiteUrl)]"
Write-Host "UserName [$($UserName)] Password [****]"


Install-PackageProvider -Name NuGet -Force -Scope "CurrentUser"
Install-Module SharePointPnPPowerShellOnline -Scope "CurrentUser" -Verbose -Force

$sp = $Password | ConvertTo-SecureString -AsPlainText -Force
$plainCred = New-Object System.Management.Automation.PSCredential ($UserName, $sp)

Connect-PnPOnline -Url $SiteUrl -Credentials $plainCred


# Add-PnPApp $packagePath -Scope Site -Overwrite -Publish #I don't know why, but using Scope Site it's fails, more detail here: https://github.com/SharePoint/PnP-PowerShell/issues/1519
Add-PnPApp $DeployPath -Overwrite -Publish
