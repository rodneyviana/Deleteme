declare interface IUselessReactWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'UselessReactWebPartStrings' {
  const strings: IUselessReactWebPartStrings;
  export = strings;
}
