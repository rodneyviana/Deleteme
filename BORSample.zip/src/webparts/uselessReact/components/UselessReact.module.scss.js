/* tslint:disable */
require("./UselessReact.module.css");
var styles = {
    uselessReact: 'uselessReact_75cf4cac',
    container: 'container_75cf4cac',
    row: 'row_75cf4cac',
    column: 'column_75cf4cac',
    'ms-Grid': 'ms-Grid_75cf4cac',
    title: 'title_75cf4cac',
    subTitle: 'subTitle_75cf4cac',
    description: 'description_75cf4cac',
    button: 'button_75cf4cac',
    label: 'label_75cf4cac'
};
export default styles;
/* tslint:enable */ 
//# sourceMappingURL=UselessReact.module.scss.js.map