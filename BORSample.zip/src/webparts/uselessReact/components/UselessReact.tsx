import * as React from 'react';
import styles from './UselessReact.module.scss';
import { IUselessReactProps } from './IUselessReactProps';
import { escape } from '@microsoft/sp-lodash-subset';

export default class UselessReact extends React.Component < IUselessReactProps, {} > {
  public render(): React.ReactElement<IUselessReactProps> {
    return(
      <div className = { styles.uselessReact } >
  <div className={styles.container}>
    <div className={styles.row}>
      <div className={styles.column}>
        <span className={styles.title}>Welcome to SharePoint! v2.0</span>
        <p className={styles.subTitle}>Customize SharePoint experiences using Web Parts.</p>
        <p className={styles.description}>{escape(this.props.description)}</p>
        <a href='https://aka.ms/spfx' className={styles.button}>
          <span className={styles.label}>Learn more</span>
        </a>
      </div>
    </div>
  </div>
      </div >
    );
  }
}
