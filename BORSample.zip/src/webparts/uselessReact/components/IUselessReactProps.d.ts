export interface IUselessReactProps {
    description: string;
}
