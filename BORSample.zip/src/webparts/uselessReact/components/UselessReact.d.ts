import * as React from 'react';
import { IUselessReactProps } from './IUselessReactProps';
export default class UselessReact extends React.Component<IUselessReactProps, {}> {
    render(): React.ReactElement<IUselessReactProps>; // tslint:disable-line
}
