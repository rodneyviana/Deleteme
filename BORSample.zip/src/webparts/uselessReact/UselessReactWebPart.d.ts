import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IUselessReactWebPartProps {
    description: string;
}
export default class UselessReactWebPart extends BaseClientSideWebPart<IUselessReactWebPartProps> {
  /* tslint:disable:member-access */
    render(): void;
    /* tslint:enable:member-access */
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
