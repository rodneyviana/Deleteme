export interface Address {
    Street: string;
    City: string;
    State: string;
    CountryOrRegion: string;
    PostalCode: string;
}
export interface Coordinates {
    Latitude: number;
    Longitude: number;
}
export interface Location {
    EntityType: string;
    LocationSource: string;
    LocationUri: string;
    UniqueId: string;
    DisplayName: string;
    Address: Address;
    Coordinates: Coordinates;
}
export interface GeoLocation extends Coordinates {
    Altitude: number;
    Measure: number;
}
