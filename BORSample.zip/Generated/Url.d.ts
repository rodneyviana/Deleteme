export interface Url {
    Url: string;
    Description: string;
}
