export interface Metadata {
    Label: string;
    TermGuid: string;
    WssId: number;
}
